#!/usr/bin/env python
# coding: utf-8

# In[1]:


import Index_with_dict
import pickle
searcher = Index_with_dict.create_dict_with_index()
with open('index_with_dict.pkl', 'wb') as f:
        pickle.dump(searcher, f)

