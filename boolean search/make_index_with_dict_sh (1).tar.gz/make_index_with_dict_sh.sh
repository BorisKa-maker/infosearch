#!/bin/bash
python3 make_index_with_dict.py
