#!/bin/bash
python3 searcher.py