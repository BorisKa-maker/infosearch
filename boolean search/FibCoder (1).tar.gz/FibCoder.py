#!/usr/bin/env python
# coding: utf-8

# In[1]:


import codecs
class FibCoder:
    
    def __init__(self,m = 30):
        self.M = {0: 0,
                  1: 1}

        def fib(n):
            if n in self.M:
                return self.M[n]
            self.M[n] = fib(n - 1) + fib(n - 2)
            return self.M[n] 
        fib(m)
    
    def encode(self,arr):
        value_list = ''
        flag = False
        for value in arr:
            value_list += '1'
            for k in list(self.M.values())[2:][::-1]:
                if k <= value:
                    value_list += '1'
                    flag = True
                    value -= k
                elif flag:
                    value_list += '0'
            flag = False
        return codecs.encode(value_list)
    
    def decode_elem(self,elem):
        tr = len(elem)
        value = 0
        for i in range(tr):
            if elem[::-1][i] == '1':
                value += list(self.M.values())[2:][i]
        return value
    
    def decode(self,val_str):
        val_str = val_str.decode()
        val_str = val_str[::-1]
        flag = False
        val_arr = []
        string=''
        for i in range(len(val_str)):
            if val_str[i]=='1':
                if flag:
                    val_arr.append(self.decode_elem(string))
                    flag = False
                    string = ''
                else:
                    flag = True
                    string = '1'+string
            else:
                string = '0'+string
                flag = False
            
        
        return val_arr[::-1]

