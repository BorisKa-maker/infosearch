#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np

import pandas as pd

import gzip

import os

import pickle

import re

from FibCoder import FibCoder

import chardet

import urllib

import base64

import pymorphy2

from nltk.corpus import stopwords

import nltk

from collections import defaultdict

from tqdm.notebook import tqdm

import codecs


from nltk.corpus import wordnet

import requests

from langdetect import detect



stop_words = set(stopwords.words(["russian", "english"]))


morph = pymorphy2.MorphAnalyzer()

class Tree():
    
    def __init__(self):
        
        self.child = {}
        
    def insert(self, word, word_id):
        
        current = self.child
        
        for l in word:
            
            if l not in current:
                
                current[l] = {}
                
            current = current[l]
            
        current['id']=word_id
        
    def search(self, word):
        
        current = self.child
        
        for l in word:
            
            if l not in current:
                return False
            current = current[l]
        return current['id']


class URL_ID:
    def __init__(self,prefix = "Infosearch/Index/dataset/"):
        self.forward = defaultdict(list)
        self.doc_url = defaultdict(str)
        self.doc_id = 1
        self.coder = FibCoder()
        for v,i in tqdm(enumerate(os.listdir(prefix))):
            with gzip.open(prefix+i, 'rb') as f:
                file = f.read().decode('utf8','ignore')
                file = re.sub(r'http://lenta.ru/news/2011/03/02/nomedal/','',file)
                http_l = re.split(r'http://lenta',file)
                for line in http_l[1:]:
                    elem = re.split(r'\x1a{1,100}',line)
                    znach = re.sub(r'\d+:\d+','',elem[1])
                    defis = re.findall(r'\w+-\w+',znach)
                    znach = re.sub(r'\w+-\w+','',znach)
                    self.doc_url[self.doc_id] = elem[0]
                    self.forward[self.doc_id] = re.findall(r'\w+',znach.lower())
                    for i in defis:
                        self.forward[self.doc_id].append(i.lower())
                    self.doc_id += 1


    def lem (self):
        for k in tqdm(self.forward.keys()):
            tmp_lst = self.forward[k]
            tmp_lst = [word for word in tmp_lst if not word in stop_words]
            for word_ind in range(len(tmp_lst)):
                tmp_lst[word_ind] = morph.parse(tmp_lst[word_ind])[0].normal_form
            self.forward[k] = tmp_lst
            
    def forward_optim_1(self):
        for k in tqdm(self.forward.keys()):
            arr = set(self.forward[k])
            d_count = defaultdict(int)
            for word in self.forward[k]:
                d_count[word] += 1
            self.forward[k] = d_count.items()
            

    def forward_optim_2(self):
        for k in tqdm(self.forward.keys()):
            arr_1 = ' '.join([x[0] for x in self.forward[k]])
            arr_2 = [x[1] for x in self.forward[k]]
            str_1 = codecs.encode(arr_1)
            str_2 = self.coder.encode(arr_2)
            self.forward[k] = [str_1,str_2]
    
    def make_dict(self):
            self.dict = Tree()
            self.count_el = 1
            for k in tqdm(self.back_index.keys()):
                self.dict.insert(k,self.count_el)
                self.count_el += 1
                
    def make_back_index(self):
        self.back_index = defaultdict(list)
        for k in tqdm(self.forward.keys()):
            for word in self.forward[k]:
                self.back_index[word[0]].append(k)
        
        self.make_dict()
        new_back_index = defaultdict(list)
        for k in tqdm(self.back_index.keys()):
            new_back_index[self.coder.encode([self.dict.search(k)])] = self.back_index[k]
        self.back_index = new_back_index
    
    def back_optim(self):
        for k in tqdm(self.back_index.keys()):
            posting_list = []
            posting_list.append(self.back_index[k][0])
            for i in range(1,len(self.back_index[k])):
                posting_list.append(self.back_index[k][i] - self.back_index[k][i-1])
            self.back_index[k] = self.coder.encode(posting_list)       

def create_dict_with_index(direction = "Infosearch/Index/dataset/"):
    searcher = URL_ID(direction)
    searcher.lem()
    searcher.forward_optim_1()
    searcher.make_back_index()
    searcher.back_optim()
    searcher.forward_optim_2()
    return searcher
        
        

