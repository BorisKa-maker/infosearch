#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pickle
import search
import codecs

with codecs.open('request.txt',encoding = 'utf-8') as f:
    request = f.read()


with open('index_with_dict.pkl', 'rb') as f:
    searcher = pickle.load(f)

search.search(request,searcher,file = 'search_result.txt')

